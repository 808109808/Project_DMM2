//By: Peizhou Huang, Zhikuo Liang, Zixuan Zhong
import java.util.Scanner
import scala.util.{Failure, Success, Try}
import java.net.{HttpURLConnection, URL}
import java.io.{File, PrintWriter}
import scala.io.Source
import play.api.libs.json._
import java.time.format.DateTimeFormatter
import java.time.{LocalDateTime, ZonedDateTime}
import showAllData.showAllData


object Main extends App {
  // Initialize a scanner to read from standard input.
  val scanner = new Scanner(System.in)
  // Define a constant for the API key.
  val apiKey = "4d6d23aded204adcbfc6db5a456a6c62"
  // Map dataset IDs to corresponding CSV filenames.
  val datasetIds = Map(181 -> "wind3min.csv", 188 -> "solar3min.csv", 191 -> "hydro3min.csv")
  // Paths to the CSV files for each energy data type.
  val hydroFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\hydro3min.csv"
  val windFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\wind3min.csv"
  val solarFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\solar3min.csv"

  // Initialize a manager to handle operations related to energy data.
  val dataManager = new EnergyDataManager(hydroFilename, windFilename, solarFilename)
  // Initialize a modifier to handle delete and add operations for data.
  val dataModifier = new deleteAdd(dataManager, formatter)
  // Initialize a handler for range queries on data.
  val rangeQueryHandler = new handleRangeQuery(dataManager, scanner, formatter)

  // Formatter for parsing and formatting dates according to a specific pattern.
  val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  // Define a cutoff date for certain operations or comparisons.
  val cutoffDate = LocalDateTime.parse("2014-01-01T00:00:00.000Z", formatter)
  // Get the current date and time in UTC.
  val today = ZonedDateTime.now(java.time.ZoneOffset.UTC)
  // Format the current datetime using the predefined formatter.
  val formattedNow = today.format(formatter)
  // Convert the formatted current datetime back to LocalDateTime for comparison.
  val nowDateTime = LocalDateTime.parse(formattedNow, formatter)
  // Regular expression pattern to validate datetime strings.
  val dateTimePattern = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z".r
  // Variables to store global start and end dates, initialized to empty.
  var globalStartDate: String = ""
  var globalEndDate: String = ""
  // List of filenames for the energy data CSV files.
  val fileNames = List(hydroFilename, windFilename, solarFilename)

  // Function to handle queries for a specific type of energy data.
  def handleQuery(dataType: String, filename: String): Unit = {
    var validDateEntered = false
    println(s"\n$dataType Data Query")
    while (!validDateEntered) {
      println("Enter the date and time in the format yyyy-MM-dd'T'HH:mm:ss.SSS'Z' or press '0' to exit:")
      val userInputDate = scanner.nextLine()
      if (userInputDate == "0") {
        return // Exit the function if the user inputs '0'.
      }

      // Check the validity of the date input by the user.
      if (checkDate(userInputDate)) {
        validDateEntered = true
        Try(dataManager.dateFormat.parse(userInputDate).getTime) match {
          case Success(timestamp) =>
            // If the date is valid, find and display the data for the specified time and type.
            dataManager.findDataByType(filename, timestamp) match {
              case Some(value) => println(s"$dataType energy at specified time: $value")
              case None => println(s"No $dataType data found at specified time.")
            }
          case Failure(_) =>
            // Print error message if date parsing fails.
            println("Invalid date format or unable to parse date. Please use the format yyyy-MM-dd'T'HH:mm:ss.SSS'Z'.")
            validDateEntered = false // Continue prompting if the date is invalid.
        }
      } else {
        println("Invalid date format. Please use the correct format and try again.")
      }
    }
  }

  // Defines a function that checks if one date is chronologically after another.
  def check2Date(date: String, date2: String): Boolean = {
    // Variable to store the result of the date comparison
    var isCompleted: Boolean = false

    // Check if both date strings match the expected date-time pattern
    if (dateTimePattern.matches(date) && dateTimePattern.matches(date2)) {
      // Parse the first date string into a LocalDateTime object
      val DateTest = LocalDateTime.parse(date, formatter)
      // Parse the second date string into a LocalDateTime object
      val Date2Test = LocalDateTime.parse(date2, formatter)

      // Check if the second date is chronologically after the first date
      if (Date2Test.isAfter(DateTest)) {
        // Set true if the second date is after the first date
        isCompleted = true
      } else {
        // Set false and print an error message if the second date is not after the first date
        isCompleted = false
        print("Your end time should be greater than your start time.\n")
      }

    } else {
      // Set false and print an error message if input dates do not match the pattern
      isCompleted = false
      println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    }
    // Return the result of the date comparison
    isCompleted
  }

  // Define a function to check if a given date string is within a specified range.
  def checkDate(date: String): Boolean = {
    // Initialize a boolean variable to track if the date is within the valid range.
    var isCompleted: Boolean = false

    // Check if the input date string matches the expected date-time pattern.
    if (dateTimePattern.matches(date)) {
      // Parse the input date string into a LocalDateTime object.
      val DateTest = LocalDateTime.parse(date, formatter)
      // Parse the start date of the range from a global variable into a LocalDateTime object.
      val startDate = LocalDateTime.parse(globalStartDate, formatter)
      // Parse the end date of the range from a global variable into a LocalDateTime object.
      val endDate = LocalDateTime.parse(globalEndDate, formatter)

      // Check if the parsed date is within the range [startDate, endDate].
      if (!DateTest.isBefore(startDate) && !DateTest.isAfter(endDate)) {
        // Set the flag to true if the date is within the range.
        isCompleted = true
      } else {
        // Set the flag to false and print an error message if the date is outside the range.
        isCompleted = false
        println("Your " + DateTest + " should be between " + startDate + " and " + endDate)
      }
    } else {
      // Set the flag to false and print an error message if the date format does not match.
      isCompleted = false
      println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    }
    // Return the boolean flag indicating whether the date was within the valid range.
    isCompleted
  }


  // Defines a function to display the main menu for user interaction.
  def mainMenu(): Unit = {
    // Prints options for the main menu.
    println("\nSelect the type of data to query or action to perform:")
    println("1. Solar Data")
    println("2. Hydro Data")
    println("3. Wind Data")
    println("4. Collect and Store Data")
    println("5. Analyze Solar Data")
    println("6. Analyze Hydro Data")
    println("7. Analyze Wind Data")
    println("8. Fetch Solar Data for a Range and Sort")
    println("9. Fetch Hydro Data for a Range and Sort")
    println("10. Fetch Wind Data for a Range and Sort")
    println("11. Generate Pie Chart of Total Energy")
    println("12. Check existing data for bugs.")
    println("13. Add or Delete Solar Data")
    println("14. Add or Delete Hydro Data")
    println("15. Add or Delete Wind Data")
    println("0. Exit")
    println("Enter your choice (0-15):")
  }

  // Function to handle the collection and storage of energy data.
  def handleDataCollection(): Unit = {
    println("\nCollecting and storing energy data...")
    dataManager.collectAndStoreData() // Calls method to collect and store data.
  }

  // Function to handle analysis of specified data.
  def handleAnalysis(dataType: String, filename: String): Unit = {
    println(s"\nAnalyzing $dataType Data...")
    dataManager.analyzeData(filename) // Calls method to analyze data from a file.
  }

  // Generic function to perform operations on a file, handles file opening and closing.
  def withFileSource[T](filename: String)(f: Iterator[String] => T): T = {
    val src = Source.fromFile(filename) // Opens the file.
    try {
      f(src.getLines()) // Applies the function 'f' to the lines of the file.
    } finally {
      src.close() // Ensures the file is closed after processing.
    }
  }

  // Function to fetch data from an API using a URL and an API key.
  def fetchData(url: String, apiKey: String): String = {
    val connection = new URL(url).openConnection().asInstanceOf[HttpURLConnection] // Opens a HTTP connection.
    connection.setRequestMethod("GET") // Sets the request method to GET.
    connection.setRequestProperty("Accept", "application/json") // Sets header for accepted response format.
    connection.setRequestProperty("x-api-key", apiKey) // Sets the API key for the request.

    val responseCode = connection.getResponseCode // Gets the HTTP response code.
    if (responseCode == HttpURLConnection.HTTP_OK) {
      val inputStream = connection.getInputStream
      val content = Source.fromInputStream(inputStream).mkString // Reads the response content as a string.
      inputStream.close() // Closes the input stream.
      content
    } else {
      throw new RuntimeException(responseCode.toString) // Throws an exception if the response is not OK.
    }
  }


  // Function to extract CSV data from JSON string.
  def extractCsvFromJson(jsonData: String): String = {
    val json = Json.parse(jsonData)  // Parse the JSON data.
    (json \ "data").as[String]  // Extract the 'data' element as a string, assuming it contains CSV data.
  }

  // Function to save a string of data to a specified file.
  def saveDataToFile(data: String, fileName: String): Unit = {
    // Create a full path for the file.
    val path = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\" + fileName
    val file = new File(path)  // Create a File object for the specified path.
    val writer = new PrintWriter(file)  // Initialize a PrintWriter for writing to the file.
    writer.write(data)  // Write data to the file.
    writer.close()  // Close the PrintWriter to finalize the write operation.
    // Uncomment to print a message indicating where the data was saved.
    // println(s"Data saved to $path")
  }

  // Function to fetch data for a specific time range and save it to files.
  def fetchDataAndSave(startTimeString: String, endTimeString: String): Either[String, Unit] = {
    var errorCodes = "200"  // Initialize the error code as "200", representing success.
    try {
      datasetIds.foreach { case (datasetId, fileName) =>
        // Construct URL to fetch data.
        val url = s"https://data.fingrid.fi/api/datasets/$datasetId/data?startTime=$startTimeString&endTime=$endTimeString&pageSize=20000&format=csv"
        // Uncomment to print messages during the fetch process.
        // println(s"Fetching data for dataset ID $datasetId")
        val rawData = fetchData(url, apiKey)  // Fetch data using the API.
        // Uncomment to confirm data fetching.
        // println("Data fetched successfully:")
        val csvData = extractCsvFromJson(rawData)  // Extract CSV from JSON.
        saveDataToFile(csvData, fileName)  // Save the CSV data to file.
      }
      Right(())  // Return Right on success, no error code.
    } catch {
      case e: Exception =>
        errorCodes = e.getMessage  // Update errorCodes with the error message from the exception.
        println(errorCodes)
        Left(errorCodes)  // Return Left containing the error message on failure.
    }
  }
  // Defines a function to control the main execution flow of the application.
  def run(): Unit = {

    // Control variable for the loop, determining if the process should continue
    var continue_1 = true
    // Counter variable for the while loop
    var a = 0

    // Loop to handle the start and end time entries until the process is marked complete
    while (a != 200) {
      // Prompt user to enter the start date and time
      println("Enter the start date (yyyy-MM-dd):")
      val startDateInput = scanner.nextLine()
      println("Enter the start time (HH:mm:ss.SSS):")
      val startTimeInput = scanner.nextLine()
      val startTimeString = startDateInput + 'T' + startTimeInput + 'Z'

      // Prompt user to enter the end date and time
      println("Enter the end date (yyyy-MM-dd):")
      val endDateInput = scanner.nextLine()
      println("Enter the end time (HH:mm:ss.SSS):")
      val endTimeInput = scanner.nextLine()
      val endTimeString = endDateInput + 'T' + endTimeInput + 'Z'

      // Validate the format of the start and end time strings
      if (dateTimePattern.matches(startTimeString) && dateTimePattern.matches(endTimeString)) {
        val startDate = LocalDateTime.parse(startTimeString, formatter)
        val endDate = LocalDateTime.parse(endTimeString, formatter)
        globalStartDate = startTimeString // Stores the globally accessible start date
        globalEndDate = endTimeString     // Stores the globally accessible end date

        // Fetch and save the data for the specified period
        val result = fetchDataAndSave(startTimeString, endTimeString)
        result match {
          case Right(_) => // If fetching and saving were successful
            if (startDate.isBefore(cutoffDate)) {
              println("The start date cannot be earlier than 2014-01-01T00:00:00.000Z.")
              a = 0
            } else if(nowDateTime.isBefore(endDate)){
              println("The end date must be no later than today's date.")
              a = 0
            } else {
              println("Operation successful.")
              a = 200  // Set a to 200 to indicate success and terminate the loop
            }
          case Left(errorCode) => // Handle errors from fetching data
            a = Try(errorCode.toInt).getOrElse(0)  // Attempt to parse errorCode to Int, reset a to 0 on failure
            if (a == 422) {
              println("There is an error in the format of time.")
              if(endDate.isBefore(startDate)){
                println("Your end time is earlier than your start time.")
              }
            } else if (a == 429) {
              println("Rate limit is exceeded. Try again in 60 seconds.")
            } else if (a == 403) {
              println("Out of call volume quota. Quota will be replenished in 23:59:59.")
            } else {
              println("There is an unknown error, please try again")
            }
        }
      } else {
        println("One or both date strings are incorrectly formatted.")
        a = 0
      }
    }

    // Menu-driven control loop for user operations
    // This loop continues as long as 'continue_1' is true, allowing for repeated menu selection.
    while (continue_1) {
      // Display the main menu to the user
      mainMenu()
      // Read the user's menu choice input
      val choice = scanner.nextLine()

      // Match the user's choice with corresponding actions
      choice match {
        // Query solar data from the specified filename
        case "1" => handleQuery("Solar", solarFilename)
        // Query hydro data from the specified filename
        case "2" => handleQuery("Hydro", hydroFilename)
        // Query wind data from the specified filename
        case "3" => handleQuery("Wind", windFilename)
        // Collect and store new data
        case "4" => handleDataCollection()
        // Analyze solar data, including statistics like average, median, mode, etc.
        case "5" => handleAnalysis("Solar", solarFilename)
        // Analyze hydro data, including statistics like average, median, mode, etc.
        case "6" => handleAnalysis("Hydro", hydroFilename)
        // Analyze wind data, including statistics like average, median, mode, etc.
        case "7" => handleAnalysis("Wind", windFilename)
        // Perform a range query on solar data and allow sorting
        case "8" => rangeQueryHandler.handleRangeQuery("Solar", solarFilename)
        // Perform a range query on hydro data and allow sorting
        case "9" => rangeQueryHandler.handleRangeQuery("Hydro", hydroFilename)
        // Perform a range query on wind data and allow sorting
        case "10" => rangeQueryHandler.handleRangeQuery("Wind", windFilename)
        // Display data from power plants within the specified global start and end dates
        case "11" => showAllData(fileNames, globalStartDate, globalEndDate)
        // Search for potentially problematic data within provided datasets
        case "12" => findFault.findFaults(Map("Hydro" -> hydroFilename, "Wind" -> windFilename, "Solar" -> solarFilename))
        // Add or delete solar data
        case "13" => dataModifier.deleteAdd("Solar", solarFilename)
        // Add or delete hydro data
        case "14" => dataModifier.deleteAdd("Hydro", hydroFilename)
        // Add or delete wind data
        case "15" => dataModifier.deleteAdd("Wind", windFilename)
        // Exit the loop and end the program
        case "0" => continue_1 = false
        // Handle unexpected menu choices
        case _ => println("Invalid choice. Please enter a number between 0 and 15.")
      }
    }
    println("Exiting the program.") // Print exit message when program ends
  }
  run() // Starts the program
}

//object Main extends App {
//  val scanner = new Scanner(System.in)
//  val apiKey = "4d6d23aded204adcbfc6db5a456a6c62"
//  val datasetIds = Map(181 -> "wind3min.csv", 188 -> "solar3min.csv", 191 -> "hydro3min.csv")
//  val hydroFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\hydro3min.csv"
//  val windFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\wind3min.csv"
//  val solarFilename = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\solar3min.csv"
//
//  val dataManager = new EnergyDataManager(hydroFilename, windFilename, solarFilename)
//  val dataModifier = new deleteAdd(dataManager, formatter)
//  val rangeQueryHandler = new handleRangeQuery(dataManager, scanner, formatter)
//
//  val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
//  val cutoffDate = LocalDateTime.parse("2014-01-01T00:00:00.000Z", formatter)
//  val today = ZonedDateTime.now(java.time.ZoneOffset.UTC)
//  val formattedNow = today.format(formatter)
//  val nowDateTime = LocalDateTime.parse(formattedNow, formatter)  // 将formattedNow字符串转换回LocalDateTime以便比较
//  val dateTimePattern = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z".r
//  var globalStartDate: String = ""
//  var globalEndDate: String = ""
//  val fileNames = List(hydroFilename, windFilename, solarFilename)
//
//  def handleQuery(dataType: String, filename: String): Unit = {
//    var validDateEntered = false
////    var userInput_1 = ''
//    println(s"\n$dataType Data Query")
////    val range = dataManager.getDateRange(filename)
////    println(s"Data available from ${range._1.getOrElse("unknown")} to ${range._2.getOrElse("unknown")}")
//    while (!validDateEntered) {
//      println("Enter the date and time in the format yyyy-MM-dd'T'HH:mm:ss.SSS'Z' or press '0' to exit:")
//      val userInputDate = scanner.nextLine()
//      // Check if user wants to exit
//      if (userInputDate == "0") {
//        return // Exit the function
//      }
//
//      // Check the validity of the date
//      if (checkDate(userInputDate)) {
//        validDateEntered = true // Set to true to break the loop if date is valid
//  //    val userInput = LocalDateTime.parse(userInputDate, formatter)
//        Try(dataManager.dateFormat.parse(userInputDate).getTime) match {
//          case Success(timestamp) =>
//            dataManager.findDataByType(filename, timestamp) match {
//              case Some(value) => println(s"$dataType energy at specified time: $value")
//              case None => println(s"No $dataType data found at specified time.")
//            }
//          case Failure(_) =>
//            println("Invalid date format or unable to parse date. Please use the format yyyy-MM-dd'T'HH:mm:ss.SSS'Z'.")
//            validDateEntered = false // Ensure loop continues if there's a parse failure
//        }
//      } else {
//        println("Invalid date format. Please use the correct format and try again.")
//      }
//    }
//  }
//  def check2Date(date: String, date2: String):Boolean = {
//    var isCompleted: Boolean = false
//    if (dateTimePattern.matches(date)&&dateTimePattern.matches(date2)) {
//      val DateTest = LocalDateTime.parse(date, formatter)
//      val Date2Test = LocalDateTime.parse(date2, formatter)
//      if (Date2Test.isAfter(DateTest)){
//        isCompleted = true
//      }else{
//        isCompleted = false
//        print("Your end time should be greater than your start time.\n")
//      }
//
//  }else{
//    isCompleted = false
//    println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
//  }
//    isCompleted
//  }
//  def checkDate(date: String): Boolean = {
//    var isCompleted: Boolean = false
//    if (dateTimePattern.matches(date)) {
//      val DateTest = LocalDateTime.parse(date, formatter)
//      val startDate = LocalDateTime.parse(globalStartDate, formatter)
//      val endDate = LocalDateTime.parse(globalEndDate, formatter)
//
//      if (!DateTest.isBefore(startDate) && !DateTest.isAfter(endDate)) {
//        isCompleted = true
//      }else{
//        isCompleted = false
//        println("Your " + DateTest + " should be between " + startDate + " and " + endDate)
//      }
//    }else{
//      isCompleted = false
//      println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
//    }
//    isCompleted
//  }
//
//  def mainMenu(): Unit = {
//    println("\nSelect the type of data to query or action to perform:")
//    println("1. Solar Data")
//    println("2. Hydro Data")
//    println("3. Wind Data")
//    println("4. Collect and Store Data")
//    println("5. Analyze Solar Data")
//    println("6. Analyze Hydro Data")
//    println("7. Analyze Wind Data")
//    println("8. Fetch Solar Data for a Range and Sort")
//    println("9. Fetch Hydro Data for a Range and Sort")
//    println("10. Fetch Wind Data for a Range and Sort")
//    println("11. Generate Pie Chart of Total Energy")
//    println("12. Check existing data for bugs.")
//    println("13. Add or Delete Solar Data")
//    println("14. Add or Delete Hydro Data")
//    println("15. Add or Delete Wind Data")
//    println("0. Exit")
//    println("Enter your choice (0-15):")
//  }
//
//  def handleDataCollection(): Unit = {
//    println("\nCollecting and storing energy data...")
//    dataManager.collectAndStoreData()
//  }
//  def handleAnalysis(dataType: String, filename: String): Unit = {
//    println(s"\nAnalyzing $dataType Data...")
//    dataManager.analyzeData(filename)
//  }
//
//  def withFileSource[T](filename: String)(f: Iterator[String] => T): T = {
//    val src = Source.fromFile(filename)
//    try {
//      f(src.getLines())
//    } finally {
//      src.close()
//    }
//  }
//
//  def fetchData(url: String, apiKey: String): String = {
//    val connection = new URL(url).openConnection().asInstanceOf[HttpURLConnection]
//    connection.setRequestMethod("GET")
//    connection.setRequestProperty("Accept", "application/json")
//    connection.setRequestProperty("x-api-key", apiKey)
//
//    val responseCode = connection.getResponseCode
//    if (responseCode == HttpURLConnection.HTTP_OK) {
//      val inputStream = connection.getInputStream
//      val content = Source.fromInputStream(inputStream).mkString
//      inputStream.close()
//      content
//    } else {
//      throw new RuntimeException(responseCode.toString)
//    }
//  }
//
//  def extractCsvFromJson(jsonData: String): String = {
//    val json = Json.parse(jsonData)
//    (json \ "data").as[String] // Directly extract CSV data
//  }
//
//  def saveDataToFile(data: String, fileName: String): Unit = {
//    val path = "E:\\LUT\\fourth period\\DMM2\\project\\Project Documents-20240502\\project\\" + fileName // 设定文件的存储路径
//    val file = new File(path)
//    val writer = new PrintWriter(file)
//    writer.write(data)
//    writer.close()
////    println(s"Data saved to $path")
//  }
//
//  def fetchDataAndSave(startTimeString: String, endTimeString: String): Either[String, Unit] = {
//    var errorCodes = "200"  // 初始化为字符串"200"，表示成功
//    try {
//      datasetIds.foreach { case (datasetId, fileName) =>
//        val url = s"https://data.fingrid.fi/api/datasets/$datasetId/data?startTime=$startTimeString&endTime=$endTimeString&pageSize=20000&format=csv"
////        println(s"Fetching data for dataset ID $datasetId")
//        val rawData = fetchData(url, apiKey)
////        println("Data fetched successfully:")
//        val csvData = extractCsvFromJson(rawData)
//        saveDataToFile(csvData, fileName)
//      }
//      Right(())  // 成功时返回Right，没有错误码
//    } catch {
//      case e: Exception =>
//        errorCodes = e.getMessage  // 出错时更新errorCodes
//        println(errorCodes)
//        Left(errorCodes)  // 返回Left，包含错误消息
//
//    }
//  }
//
//
//  def run(): Unit = {
//
//    var continue_1 = true
//    var a = 0
//
//    while (a != 200) {
//      println("Enter the start date (yyyy-MM-dd):")
//      val startDateInput = scanner.nextLine()
//      println("Enter the start time (HH:mm:ss.SSS):")
//      val startTimeInput = scanner.nextLine()
//      val startTimeString = startDateInput + 'T' + startTimeInput + 'Z'
//
//
//      println("Enter the end date (yyyy-MM-dd):")
//      val endDateInput = scanner.nextLine()
//      println("Enter the end time (HH:mm:ss.SSS):")
//      val endTimeInput = scanner.nextLine()
//      val endTimeString = endDateInput + 'T' + endTimeInput + 'Z'
//
//
//      if (dateTimePattern.matches(startTimeString) && dateTimePattern.matches(endTimeString)) {
//        val startDate = LocalDateTime.parse(startTimeString, formatter)
//        val endDate = LocalDateTime.parse(endTimeString, formatter)
//        globalStartDate = startTimeString
////        println(globalStartDate)
//        globalEndDate = endTimeString
//        val result = fetchDataAndSave(startTimeString, endTimeString)
//        result match {
//          case Right(_) =>
//            if (startDate.isBefore(cutoffDate)) {
//              println("The start date cannot be earlier than 2014-01-01T00:00:00.000Z.")
//              a = 0
//            }else if(nowDateTime.isBefore(endDate)){
//              println("The end date must be no later than today's date.")
//              a = 0
//            } else {
//              println("Operation successful.")
//              a = 200  // 设置 a 为 200 表示成功，终止循环
//            }
//          case Left(errorCode) =>
//            a = Try(errorCode.toInt).getOrElse(0)  // 尝试将 errorCode 转换为 Int，如果失败则设置 a 为 0
//            //          println(a)
//            if (a == 422) {
//              println("There is an error in the format of time.") // 输出变量a的值
//              if(endDate.isBefore(startDate)){
//                println("Your end time is earlier than your start time.")
//              }
//            }else if(a == 429){
//              println("Rate limit is exceeded. Try again in 60 seconds.")
//            }else if(a == 403){
//              println("Out of call volume quota. Quota will be replenished in 23:59:59.")
//            }else{
//              println("There is an unknown error, please try again")
//            }
//        }
//      } else {
//        println("One or both date strings are incorrectly formatted.")
//        a = 0
//      }
//    }
//
//
////    ---
//    while (continue_1) {
//      mainMenu()
//      val choice = scanner.nextLine()
//      choice match {
////        4 搜索数据
//        case "1" => handleQuery("Solar", solarFilename)
//        case "2" => handleQuery("Hydro", hydroFilename)
//        case "3" => handleQuery("Wind", windFilename)
////        2存储数据
//        case "4" => handleDataCollection()
////        4数据分析 平均数，中位数，模式等等
//        case "5" => handleAnalysis("Solar", solarFilename)
//        case "6" => handleAnalysis("Hydro", hydroFilename)
//        case "7" => handleAnalysis("Wind", windFilename)
////        4搜索一定数据的范围的数据并允许排序
//        case "8" => rangeQueryHandler.handleRangeQuery("Solar", solarFilename)
//        case "9" => rangeQueryHandler.handleRangeQuery("Hydro", hydroFilename)
//        case "10" => rangeQueryHandler.handleRangeQuery("Wind", windFilename)
////        3提供发电厂的数据
//        case "11" => showAllData(fileNames, globalStartDate, globalEndDate)
////        5查找是否有有问题的数据
//        case "12" => findFault.findFaults(Map("Hydro" -> hydroFilename, "Wind" -> windFilename, "Solar" -> solarFilename))
////        1控制数据
//        case "13" => dataModifier.deleteAdd("Solar", solarFilename)
//        case "14" => dataModifier.deleteAdd("Hydro", hydroFilename)
//        case "15" => dataModifier.deleteAdd("Wind", windFilename)
//        case "0" => continue_1 = false
//        case _ => println("Invalid choice. Please enter a number between 0 and 15.")
//      }
//    }
//    println("Exiting the program.")
//  }
//  run() // 启动程序
//}