//By: Peizhou Huang, Zhikuo Liang, Zixuan Zhong
import java.time.format.DateTimeFormatter
import java.time.ZonedDateTime
import scala.io.Source

// Define an object `findFault` for identifying data inconsistencies in energy readings
object findFault {
  // Set up a DateTimeFormatter for parsing ISO 8601 UTC timestamps
  val dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(java.time.ZoneId.of("UTC"))

  // Define a function `findFaults` to check for unusual energy readings in multiple files
  def findFaults(fileNames: Map[String, String]): Unit = {
    var faultFound = false // Initialize a flag to track whether any faults were found

    // Iterate over the map of energy types and corresponding filenames
    fileNames.foreach { case (energyType, filename) =>
      val src = Source.fromFile(filename) // Open the file specified by filename
      try {
        val lines = src.getLines() // Read lines from the file
        val header = lines.next() // Extract the header line
        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime") // Find the index of the startTime column
        val valueIndex = header.split(",").indexWhere(_.trim == "value") // Find the index of the value column
        // Process remaining lines to extract timestamps and values
        val values = lines.map { line =>
          val parts = line.split(",")
          (ZonedDateTime.parse(parts(startTimeIndex), dateTimeFormatter), parts(valueIndex).toDouble)
        }.toList

        // Implement fault detection logic
        val totalCount = values.length // Total number of data points
        val lowValuesCount = values.count(_._2 < 100) // Count of values below 100
        val veryLowValuesCount = values.count(_._2 < 500) // Count of values below 500

        // Check for significant proportion of low readings
        if (lowValuesCount.toDouble / totalCount >= 0.2) {
          println(s"$energyType energy may have data faults. $lowValuesCount out of $totalCount readings are below 100.")
          faultFound = true
        }
        // Check for very low output levels
        if (veryLowValuesCount.toDouble / totalCount >= 0.5) {
          println(s"$energyType energy may have low energy output. $veryLowValuesCount out of $totalCount readings are below 500.")
          faultFound = true
        }
      } finally {
        src.close() // Ensure the file is closed after processing
      }
    }

    // Provide a final status report based on the detection results
    if (!faultFound) {
      println("No faults found.")
    }
  }
}

//The version without comments:
//object findFault {
//  val dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(java.time.ZoneId.of("UTC"))
//
//  def findFaults(fileNames: Map[String, String]): Unit = {
//    var faultFound = false
//
//    fileNames.foreach { case (energyType, filename) =>
//      val src = Source.fromFile(filename)
//      try {
//        val lines = src.getLines()
//        val header = lines.next()
//        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime")
//        val valueIndex = header.split(",").indexWhere(_.trim == "value")
//        val values = lines.map { line =>
//          val parts = line.split(",")
//          (ZonedDateTime.parse(parts(startTimeIndex), dateTimeFormatter), parts(valueIndex).toDouble)
//        }.toList
//
//        // Filtering and fault detection logic...
//        val totalCount = values.length
//        val lowValuesCount = values.count(_._2 < 100)
//        val veryLowValuesCount = values.count(_._2 < 500)
//
//        if (lowValuesCount.toDouble / totalCount >= 0.2) {
//          println(s"$energyType energy may have data faults. $lowValuesCount out of $totalCount readings are below 100.")
//          faultFound = true
//        }
//        if (veryLowValuesCount.toDouble / totalCount >= 0.5) {
//          println(s"$energyType energy may have low energy output. $veryLowValuesCount out of $totalCount readings are below 500.")
//          faultFound = true
//        }
//      } finally {
//        src.close()
//      }
//    }
//
//    if (!faultFound) {
//      println("No faults found.")
//    }
//  }
//}
