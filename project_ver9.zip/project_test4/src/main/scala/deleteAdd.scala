//By: Peizhou Huang, Zhikuo Liang, Zixuan Zhong
import  Main.check2Date
import java.io.{File, PrintWriter}
import scala.io.Source
import java.text.SimpleDateFormat
import java.util.Scanner
import java.time.format.DateTimeFormatter
// Define a class `deleteAdd` to handle adding and deleting data entries for different energy types.
class deleteAdd(dataManager: EnergyDataManager, formatter: DateTimeFormatter) {
  // Define a method `deleteAdd` that handles adding or deleting data entries based on user input.
  def deleteAdd(dataType: String, filename: String): Unit = {
    // Notify the user of the data type being handled.
    println(s"\nHandling $dataType Data")
    val scanner = new Scanner(System.in) // Instantiate a scanner to read user input.

    // Ask the user to choose an action between adding or deleting data.
    println("Choose action: 1 for Add, 2 for Delete")
    val action = scanner.nextLine()

    // Prompt the user to enter the start and end times for the data entry.
    println("Enter start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
    val startTime = scanner.nextLine()
    println("Enter end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
    val endTime = scanner.nextLine()

    // Validate the start and end times entered by the user.
    if (!check2Date(startTime, endTime)) {
      // Inform the user of invalid date format or range and retry.
      println("Invalid date format or date range. Please try again.")
      deleteAdd(dataType, filename) // Recursive call to restart the method if validation fails.
      return // Early return for clarity, prevents further execution if dates are invalid.
    }

    // Determine the action based on user selection and execute the corresponding function.
    action match {
      case "1" => // Case for adding data.
        println("Enter value:")
        val value = scanner.nextLine().toDouble // Read and convert the input value to double.
        // Check the data type and assign the appropriate ID for adding data.
        if (dataType == "Solar") {
          val ID = 188 // Example ID for solar data.
          addData(ID, startTime, endTime, value, filename) // Add solar data.
        } else if (dataType == "Hydro") {
          val ID = 191 // Example ID for hydro data.
          addData(ID, startTime, endTime, value, filename) // Add hydro data.
        } else if (dataType == "Wind") {
          val ID = 181 // Example ID for wind data.
          addData(ID, startTime, endTime, value, filename) // Add wind data.
        } else {
          // Handle an unexpected data type or filename error.
          println("Incorrect data type or filename error.")
        }
      case "2" => // Case for deleting data.
        deleteData(startTime, endTime, filename) // Execute deletion based on the specified time range.
      case _ => // Handle invalid action choice.
        println("Invalid action chosen.") // Inform the user of an incorrect choice.
    }
  }

  // Define a method `addData` to add a new data entry to a specified file.
  def addData(datasetId: Int, startTime: String, endTime: String, value: Double, filename: String): Unit = {
    // Format the new data entry as a string.
    val newData = s"$datasetId,$startTime,$endTime,$value"
    // Open the file specified by `filename`.
    val file = new File(filename)
    // Read all existing lines from the file into a list.
    val lines = Source.fromFile(file).getLines.toList
    // Append the new data entry to the end of the existing lines.
    val updatedLines = lines :+ newData
    // Write the updated list of lines back to the file.
    writeToFile(updatedLines, filename)
  }


  // Function to delete data within a specific time range from a file.
  def deleteData(startTime: String, endTime: String, filename: String): Unit = {
    val file = new File(filename)  // Create a File object with the specified filename.
    val lines = Source.fromFile(file).getLines.toList  // Read all lines from the file into a list.
    val header = lines.head  // Retain the header line.
    val dataLines = lines.tail  // Remove the header line, only process data lines.

    val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")  // Define the date format.
    val startTimestamp = dateFormat.parse(startTime).getTime  // Convert the start time to a timestamp.
    val endTimestamp = dateFormat.parse(endTime).getTime  // Convert the end time to a timestamp.

    // Filter and retain lines outside the specified time range.
    val updatedLines = header +: dataLines.filterNot { line =>
      val parts = line.split(",")  // Split the line into columns.
      val lineStartTimestamp = dateFormat.parse(parts(1)).getTime  // Assume start time is in the second column.
      val lineEndTimestamp = dateFormat.parse(parts(2)).getTime  // Assume end time is in the third column.
      lineStartTimestamp >= startTimestamp && lineEndTimestamp <= endTimestamp  // Check if the line is within the time range.
    }
    writeToFile(updatedLines, filename)  // Write the filtered lines back to the file.
  }



  // Function to write a list of strings to a file.
  def writeToFile(lines: List[String], filename: String): Unit = {
    val pw = new PrintWriter(new File(filename))  // Create a PrintWriter object for the specified file.
    lines.foreach(pw.println)  // Write each line in the list to the file.
    pw.close()  // Close the PrintWriter to free resources and flush the contents to the file.
  }
}



//The version without comments:
//class deleteAdd(dataManager: EnergyDataManager, formatter: DateTimeFormatter) {
//  def deleteAdd(dataType: String, filename: String): Unit = {
//    println(s"\nHandling $dataType Data")
//    val scanner = new Scanner(System.in)
//
//    println("Choose action: 1 for Add, 2 for Delete")
//    val action = scanner.nextLine()
//
//    println("Enter start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
//    val startTime = scanner.nextLine()
//    println("Enter end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
//    val endTime = scanner.nextLine()
//
//
//    if (!check2Date(startTime,endTime)) {
//      println("Invalid date format or date range. Please try again.")
//      deleteAdd(dataType, filename) // execute for side effects without returning
//      return // early exit for clarity, if needed
//    }
//
//    action match {
//      case "1" => // Add data
//        println("Enter value:")
//        val value = scanner.nextLine().toDouble // Assume value is a double
//        if (dataType == "Solar"){
//          val ID = 188
//          addData(ID, startTime, endTime, value, filename)
//        }else if(dataType == "Hydro"){
//          val ID = 191
//          addData(ID, startTime, endTime, value, filename)
//        }else if(dataType == "Wind"){
//          val ID = 181
//          addData(ID, startTime, endTime, value, filename)
//        }else{
//          println("add_delete的文件名出现错误。")
//        }
//      //        addData(startTime, endTime, value, filename)
//      case "2" => // Delete data
//        deleteData(startTime, endTime, filename)
//      case _ =>
//        println("Invalid action chosen.")
//    }
//  }
//  def addData(datasetId:Int, startTime: String, endTime: String, value: Double, filename: String): Unit = {
//    val newData = s"$datasetId,$startTime,$endTime,$value"
//    val file = new File(filename)
//    val lines = Source.fromFile(file).getLines.toList
//    val updatedLines = lines :+ newData // Add new data line to the end
//    writeToFile(updatedLines, filename)
//  }
//
//  def deleteData(startTime: String, endTime: String, filename: String): Unit = {
//    val file = new File(filename)
//    val lines = Source.fromFile(file).getLines.toList
//    val header = lines.head  // 保留标题行
//    val dataLines = lines.tail  // 移除标题行，仅处理数据行
//
//    val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
//    val startTimestamp = dateFormat.parse(startTime).getTime
//    val endTimestamp = dateFormat.parse(endTime).getTime
//
//    val updatedLines = header +: dataLines.filterNot { line =>
//      val parts = line.split(",")
//      val lineStartTimestamp = dateFormat.parse(parts(1)).getTime  // 假设开始时间在第二列
//      val lineEndTimestamp = dateFormat.parse(parts(2)).getTime  // 假设结束时间在第三列
//      lineStartTimestamp >= startTimestamp && lineEndTimestamp <= endTimestamp
//    }
//    writeToFile(updatedLines, filename)
//  }
//
//
//  def writeToFile(lines: List[String], filename: String): Unit = {
//    val pw = new PrintWriter(new File(filename))
//    lines.foreach(pw.println)
//    pw.close()
//  }
//}
