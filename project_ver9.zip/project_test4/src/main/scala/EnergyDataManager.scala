//By: Peizhou Huang, Zhikuo Liang, Zixuan Zhong
import java.io.{File, PrintWriter}
import java.text.SimpleDateFormat
import scala.io.Source
import scala.util.{Try}

// Define a class for managing energy data from hydro, wind, and solar sources.
class EnergyDataManager(hydroFilename: String, windFilename: String, solarFilename: String) {
  // Formatter to parse ISO 8601 formatted date strings.
  val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")

  // Method to find data by its type using a given filename and timestamp. Returns an optional Double value.
  def findDataByType(filename: String, timestamp: Long): Option[Double] = {
    // Process the file and extract required data lines.
    withFileSource(filename) { lines =>
      lines.map { line =>
        // Clean and split each line, removing unnecessary double quotes.
        val parts = line.trim.split(",").map(_.trim.replaceAll("\"", ""))
        parts
      }.find { parts =>
        // Find a line where the second part (timestamp) matches the provided timestamp.
        parts.length > 2 && Try(dateFormat.parse(parts(1)).getTime == timestamp).getOrElse(false)
      }.flatMap { matchedParts =>
        // If a matching line is found, attempt to parse the fourth part as a double.
        Try(matchedParts(3).toDouble).toOption
      }
    }
  }

  // Helper method to handle file processing and ensure the file source is closed after use.
  private def withFileSource[T](filename: String)(f: Iterator[String] => T): T = {
    val src = Source.fromFile(filename)
    try {
      f(src.getLines())
    } finally {
      src.close()
    }
  }

  // Method to collect data from all sources and store it in a single output file.
  def collectAndStoreData(): Unit = {
    val outputFile = new File("collected_data.txt")
    val pw = new PrintWriter(outputFile)
    try {
      pw.println("Collected data on renewable energy sources:")
      // Iterate over each file, read and process its contents.
      val fileNames = List(hydroFilename, windFilename, solarFilename)
      fileNames.foreach { file =>
        val source = Source.fromFile(file)
        try {
          val lines = source.getLines().drop(1) // Skip the title line assuming it's a header.
          lines.foreach(line => {
            val data = line.split(",").map(_.trim)
            val datasetid = data(0)
            val time = data(1)  // Assume the second field is time.
            val time2 = data(2)
            val energy = data(3) // Assume the third field is energy data.
            // Print collected data from the dataset.
            pw.println(s"Datasetid: $datasetid, Time: $time-$time2 Energy: $energy kWh from $file")
          })
        } finally {
          source.close()
        }
      }
    } finally {
      pw.close()
    }
    println("Data has been collected and stored in " + outputFile.getPath)
  }

  // Method to analyze data from a file and print statistical measurements.
  def analyzeData(filename: String): Unit = {
    val source = Source.fromFile(filename)
    try {
      val data = source.getLines().drop(1) // Assume the first line is a header.
        .map(_.split(",").last.trim.replaceAll("\"", "")) // Remove quotes and trim.
        .filter(_.matches("-?\\d+(\\.\\d+)?")) // Ensure the data is numeric.
        .map(_.toDouble) // Convert to Double safely.
        .toList

      // Calculate statistical metrics if data is present.
      if (data.isEmpty) {
        println("No data available for analysis.")
        return
      }

      val mean = data.sum / data.size
      val sorted = data.sorted
      val median = if (sorted.size % 2 == 1) sorted(sorted.size / 2) else (sorted(sorted.size / 2 - 1) + sorted(sorted.size / 2)) / 2.0
      val mode = data.groupBy(identity).maxBy(_._2.size)._1
      val range = sorted.last - sorted.head
      val midrange = (sorted.head + sorted.last) / 2.0

      // Print calculated values.
      println(s"Mean: $mean")
      println(s"Median: $median")
      println(s"Mode: $mode")
      println(s"Range: $range")
      println(s"Midrange: $midrange")
    } finally {
      source.close()
    }
  }

  // Method to fetch data within a specified time range from a file.
  def fetchDataInRange(filename: String, startTime: String, endTime: String): List[Array[String]] = {
    val src = Source.fromFile(filename)
    try {
      val data = src.getLines().drop(1).map(_.split(",")).filter { parts =>
        // Parse and filter lines based on the timestamp range.
        val timestamp = dateFormat.parse(parts(1)).getTime
        timestamp >= dateFormat.parse(startTime).getTime && timestamp <= dateFormat.parse(endTime).getTime
      }.toList
      data
    } finally {
      src.close()
    }
  }

  // Method to print data and optionally sort it based on the last column's numeric value.
  def printData(data: List[Array[String]], shouldSort: Boolean): Unit = {
    val sortedData = if (shouldSort) {
      data.sortBy(parts => parts.last.toDouble) // Assume the last column can be converted to Double.
    } else data

    // Print each part of the sorted or unsorted data.
    sortedData.foreach { parts =>
      println(parts.mkString(", "))
    }
  }
}


//The version without comments:
//class EnergyDataManager(hydroFilename: String, windFilename: String, solarFilename: String) {
//  val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
//  def findDataByType(filename: String, timestamp: Long): Option[Double] = {
//    withFileSource(filename) { lines =>
//      lines.map { line =>
//        val parts = line.trim.split(",").map(_.trim.replaceAll("\"", "")) // Remove double quotes directly here
//        parts
//      }.find { parts =>
//        parts.length > 2 && Try(dateFormat.parse(parts(1)).getTime == timestamp).getOrElse(false)
//      }.flatMap { matchedParts =>
//        Try(matchedParts(3).toDouble).toOption
//      }
//    }
//  }
//
//
//  private def withFileSource[T](filename: String)(f: Iterator[String] => T): T = {
//    val src = Source.fromFile(filename)
//    try {
//      f(src.getLines())
//    } finally {
//      src.close()
//    }
//  }
//
//  def collectAndStoreData(): Unit = {
//    val outputFile = new File("collected_data.txt")
//    val pw = new PrintWriter(outputFile)
//    try {
//      pw.println("Collected data on renewable energy sources:")
//      // 读取并处理每个文件
//      val fileNames = List(hydroFilename, windFilename, solarFilename)
//      fileNames.foreach { file =>
//        val source = Source.fromFile(file)
//        try {
//          val lines = source.getLines().drop(1) // 假设第一行是标题
//          lines.foreach(line => {
//            val data = line.split(",").map(_.trim)
//            val datasetid = data(0)
//            val time = data(1)  // 假设时间是每行的第一个字段
//            val time2 = data(2)
//            val energy = data(3) // 假设能量数据是第二个字段
//            pw.println(s"Datasetid: $datasetid, Time: $time-$time2 Energy: $energy kWh from $file")
//          })
//        } finally {
//          source.close()
//        }
//      }
//    } finally {
//      pw.close()
//    }
//    println("Data has been collected and stored in " + outputFile.getPath)
//  }
//
//  def analyzeData(filename: String): Unit = {
//    val source = Source.fromFile(filename)
//    try {
//      val data = source.getLines().drop(1) // 假设第一行是标题
//        .map(_.split(",").last.trim.replaceAll("\"", "")) // 移除引号并修正
//        .filter(_.matches("-?\\d+(\\.\\d+)?")) // 确保是数字
//        .map(_.toDouble) // 安全地转换为Double
//        .toList
//
//      if (data.isEmpty) {
//        println("No data available for analysis.")
//        return
//      }
//
//      val mean = data.sum / data.size
//      val sorted = data.sorted
//      val median = if (sorted.size % 2 == 1) sorted(sorted.size / 2) else (sorted(sorted.size / 2 - 1) + sorted(sorted.size / 2)) / 2.0
//      val mode = data.groupBy(identity).maxBy(_._2.size)._1
//      val range = sorted.last - sorted.head
//      val midrange = (sorted.head + sorted.last) / 2.0
//
//      println(s"Mean: $mean")
//      println(s"Median: $median")
//      println(s"Mode: $mode")
//      println(s"Range: $range")
//      println(s"Midrange: $midrange")
//    } finally {
//      source.close()
//    }
//  }
//
//  def fetchDataInRange(filename: String, startTime: String, endTime: String): List[Array[String]] = {
//    val src = Source.fromFile(filename)
//    try {
//      val data = src.getLines().drop(1).map(_.split(",")).filter { parts =>
//        val timestamp = dateFormat.parse(parts(1)).getTime
//        timestamp >= dateFormat.parse(startTime).getTime && timestamp <= dateFormat.parse(endTime).getTime
//      }.toList
//      data
//    } finally {
//      src.close()
//    }
//  }
//
//  def printData(data: List[Array[String]], shouldSort: Boolean): Unit = {
//    val sortedData = if (shouldSort) {
//      data.sortBy(parts => parts.last.toDouble) // 假设最后一列可以转换为 Double
//    } else data
//
//    sortedData.foreach { parts =>
//      println(parts.mkString(", "))
//    }
//  }
//
//}
