//By: Peizhou Huang, Zhikuo Liang, Zixuan Zhong

import scala.io.Source

// Define an object `showAllData` that contains methods for displaying data
object showAllData {
  // Define a method `showAllData` that processes a list of filenames and a global date range
  def showAllData(fileNames: List[String], globalStartDate: String, globalEndDate: String): Unit = {
    // Initialize a variable to accumulate total energy across all files
    var totalEnergy = 0.0
    // Use a mutable map to store total energy per file
    val energies = scala.collection.mutable.Map[String, Double]()

    // Iterate through each filename in the list of filenames
    fileNames.foreach { filename =>
      // Open the file for reading
      val src = Source.fromFile(filename)
      try {
        // Read lines from the file
        val lines = src.getLines()
        // Extract the first line as header
        val header = lines.next()
        // Identify the indices of start time, end time, and value in the header
        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime")
        val endTimeIndex = header.split(",").indexWhere(_.trim == "endTime")
        val valueIndex = header.split(",").indexWhere(_.trim == "value")
        // Process each subsequent line to extract energy data
        val energyData = lines.map { line =>
          val parts = line.split(",")
          (parts(startTimeIndex), parts(endTimeIndex), parts(valueIndex).toDouble)
        }.toList

        // Gather all start and end dates from the energy data
        val dates = energyData.map(_._1) ++ energyData.map(_._2)
        // Determine the minimum and maximum date
        val minDate = dates.min
        val maxDate = dates.max
        // Calculate total energy from the file
        val total = energyData.map(_._3).sum

        // Print details about the file's data range and total energy
        println(s"${filename.split("\\\\").last}:")
        println(s"Data range: $minDate to $maxDate")
        println(s"Total Energy: $total kWh")

        // Update the energies map and the total energy accumulator
        energies(filename.split("\\\\").last) = total
        totalEnergy += total
      } finally {
        // Ensure the file is closed after processing
        src.close()
      }
    }

    // Print the total energy summed from all files
    println(s"\nTotal Energy from all sources: $totalEnergy kWh")
    // Calculate and print the percentage contribution of each source
    energies.foreach { case (source, energy) =>
      val percentage = (energy / totalEnergy) * 100
      println(s"Percentage of $source: $percentage%")
    }
  }
}
//The version without comments:
//object showAllData {
//  def showAllData(fileNames: List[String], globalStartDate: String, globalEndDate: String): Unit = {
//    var totalEnergy = 0.0
//    val energies = scala.collection.mutable.Map[String, Double]()
//
//    fileNames.foreach { filename =>
//      val src = Source.fromFile(filename)
//      try {
//        val lines = src.getLines()
//        val header = lines.next()
//        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime")
//        val endTimeIndex = header.split(",").indexWhere(_.trim == "endTime")
//        val valueIndex = header.split(",").indexWhere(_.trim == "value")
//        val energyData = lines.map { line =>
//          val parts = line.split(",")
//          (parts(startTimeIndex), parts(endTimeIndex), parts(valueIndex).toDouble)
//        }.toList
//
//        val dates = energyData.map(_._1) ++ energyData.map(_._2)
//        val minDate = dates.min
//        val maxDate = dates.max
//        val total = energyData.map(_._3).sum
//
//        println(s"${filename.split("\\\\").last}:")
//        println(s"Data range: $minDate to $maxDate")
//        println(s"Total Energy: $total kWh")
//
//        energies(filename.split("\\\\").last) = total
//        totalEnergy += total
//      } finally {
//        src.close()
//      }
//    }
//
//    println(s"\nTotal Energy from all sources: $totalEnergy kWh")
//    energies.foreach { case (source, energy) =>
//      val percentage = (energy / totalEnergy) * 100
//      println(s"Percentage of $source: $percentage%")
//    }
//  }
//}