//By: Peizhou Huang, Zhikuo Liang, Zixuan Zhong
import java.util.Scanner
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// Define a class to handle range queries for energy data
class handleRangeQuery(dataManager: EnergyDataManager, scanner: Scanner, formatter: DateTimeFormatter) {
  // Regular expression to validate datetime strings
  val dateTimePattern = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z".r

  // Method to handle a range query based on user input
  def handleRangeQuery(dataType: String, filename: String): Unit = {
    // Flags to control the loop based on valid input times
    var start = false
    var end = false
    while (!start && !end) {
      // Prompt user to enter the start time or quit by pressing '0'
      println(s"\nEnter the start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
      val startTimeString = scanner.nextLine()
      // Prompt user to enter the end time or quit by pressing '0'
      println("Enter the end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
      val endTimeString = scanner.nextLine()

      // Check if user wants to exit the function
      if (startTimeString == "0" || endTimeString == "0") {
        return // Exit the function
      }

      // Validate start and end times and process the data accordingly
      if (checkDate(startTimeString) && checkDate(endTimeString)) {
        start = true
        end = true
        // Fetch data for the given date range and filename
        val data = dataManager.fetchDataInRange(filename, startTimeString, endTimeString)
        // Ask user if they want to sort the data by value
        println(s"\nDo you want to sort the data by the value. (Y/N)?")
        val shouldSort = scanner.nextLine().toUpperCase
        // Print the data, sorted if requested
        dataManager.printData(data, shouldSort == "Y")
      } else if(checkDate(startTimeString) && !checkDate(endTimeString)){
        println("There is a problem with your end time input.")
      } else if(!checkDate(startTimeString) && checkDate(endTimeString)){
        println("There is a problem with your start time input.")
      } else{
        // Parse the dates to check their order
        val startDate = LocalDateTime.parse(startTimeString, formatter)
        val endDate = LocalDateTime.parse(endTimeString, formatter)
        // Ensure the end time is not before the start time
        if(endDate.isBefore(startDate)){
          println("Your end time is earlier than your start time.")
        }else{
          println("Something wrong.")
        }
      }
    }
  }

  // Helper function to check if a date string matches the expected format
  private def checkDate(date: String): Boolean = {
    if (dateTimePattern.matches(date)) {
      true
    } else {
      println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
      false
    }
  }
}


//The version without comments:
//class handleRangeQuery(dataManager: EnergyDataManager, scanner: Scanner, formatter: DateTimeFormatter) {
//  val dateTimePattern = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z".r
//
//  def handleRangeQuery(dataType: String, filename: String): Unit = {
//    var start = false
//    var end = false
//    while (!start && !end) {
//      println(s"\nEnter the start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
//      val startTimeString = scanner.nextLine()
//      println("Enter the end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
//      val endTimeString = scanner.nextLine()
//      // Check if user wants to exit
//      if (startTimeString == "0" || endTimeString == "0") {
//        return // Exit the function
//      }
//
//      if (checkDate(startTimeString) && checkDate(endTimeString)) {
//        start = true
//        end = true
//        val data = dataManager.fetchDataInRange(filename, startTimeString, endTimeString)
//        println(s"\nDo you want to sort the data by the value. (Y/N)?")
//        val shouldSort = scanner.nextLine().toUpperCase
//        dataManager.printData(data, shouldSort == "Y")
//      } else if(checkDate(startTimeString) && !checkDate(endTimeString)){
//        println("There is a problem with your end time input.")
//      } else if(!checkDate(startTimeString) && checkDate(endTimeString)){
//        println("There is a problem with your start time input.")
//      } else{
//        val startDate = LocalDateTime.parse(startTimeString, formatter)
//        val endDate = LocalDateTime.parse(endTimeString, formatter)
//        if(endDate.isBefore(startDate)){
//          println("Your end time is earlier than your start time.")
//        }else{
//          println("Something wrong.")
//        }
//      }
//    }
//  }
//
//  private def checkDate(date: String): Boolean = {
//    if (dateTimePattern.matches(date)) {
//      true
//    } else {
//      println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
//      false
//    }
//  }
//}
