import java.time.format.DateTimeFormatter
import java.time.ZonedDateTime
import scala.io.Source

object findFault {
  val dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(java.time.ZoneId.of("UTC"))

  def findFaults(fileNames: Map[String, String]): Unit = {
    var faultFound = false

    fileNames.foreach { case (energyType, filename) =>
      val src = Source.fromFile(filename)
      try {
        val lines = src.getLines()
        val header = lines.next()
        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime")
        val valueIndex = header.split(",").indexWhere(_.trim == "value")
        val values = lines.map { line =>
          val parts = line.split(",")
          (ZonedDateTime.parse(parts(startTimeIndex), dateTimeFormatter), parts(valueIndex).toDouble)
        }.toList

        // Filtering and fault detection logic...
        val totalCount = values.length
        val lowValuesCount = values.count(_._2 < 100)
        val veryLowValuesCount = values.count(_._2 < 500)

        if (lowValuesCount.toDouble / totalCount >= 0.2) {
          println(s"$energyType energy may have data faults. $lowValuesCount out of $totalCount readings are below 100.")
          faultFound = true
        }
        if (veryLowValuesCount.toDouble / totalCount >= 0.5) {
          println(s"$energyType energy may have low energy output. $veryLowValuesCount out of $totalCount readings are below 500.")
          faultFound = true
        }
      } finally {
        src.close()
      }
    }

    if (!faultFound) {
      println("No faults found.")
    }
  }
}
