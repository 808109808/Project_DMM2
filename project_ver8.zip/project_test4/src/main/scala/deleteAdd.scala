import  Main.check2Date
import java.io.{File, PrintWriter}
import scala.io.Source
import java.text.SimpleDateFormat
import java.util.Scanner
import java.time.format.DateTimeFormatter

class deleteAdd(dataManager: EnergyDataManager, formatter: DateTimeFormatter) {
  def deleteAdd(dataType: String, filename: String): Unit = {
    println(s"\nHandling $dataType Data")
    val scanner = new Scanner(System.in)

    println("Choose action: 1 for Add, 2 for Delete")
    val action = scanner.nextLine()

    println("Enter start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
    val startTime = scanner.nextLine()
    println("Enter end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):")
    val endTime = scanner.nextLine()


    if (!check2Date(startTime,endTime)) {
      println("Invalid date format or date range. Please try again.")
      deleteAdd(dataType, filename) // execute for side effects without returning
      return // early exit for clarity, if needed
    }

    action match {
      case "1" => // Add data
        println("Enter value:")
        val value = scanner.nextLine().toDouble // Assume value is a double
        if (dataType == "Solar"){
          val ID = 188
          addData(ID, startTime, endTime, value, filename)
        }else if(dataType == "Hydro"){
          val ID = 191
          addData(ID, startTime, endTime, value, filename)
        }else if(dataType == "Wind"){
          val ID = 181
          addData(ID, startTime, endTime, value, filename)
        }else{
          println("add_delete的文件名出现错误。")
        }
      //        addData(startTime, endTime, value, filename)
      case "2" => // Delete data
        deleteData(startTime, endTime, filename)
      case _ =>
        println("Invalid action chosen.")
    }
  }
  def addData(datasetId:Int, startTime: String, endTime: String, value: Double, filename: String): Unit = {
    val newData = s"$datasetId,$startTime,$endTime,$value"
    val file = new File(filename)
    val lines = Source.fromFile(file).getLines.toList
    val updatedLines = lines :+ newData // Add new data line to the end
    writeToFile(updatedLines, filename)
  }

  def deleteData(startTime: String, endTime: String, filename: String): Unit = {
    val file = new File(filename)
    val lines = Source.fromFile(file).getLines.toList
    val header = lines.head  // 保留标题行
    val dataLines = lines.tail  // 移除标题行，仅处理数据行

    val dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    val startTimestamp = dateFormat.parse(startTime).getTime
    val endTimestamp = dateFormat.parse(endTime).getTime

    val updatedLines = header +: dataLines.filterNot { line =>
      val parts = line.split(",")
      val lineStartTimestamp = dateFormat.parse(parts(1)).getTime  // 假设开始时间在第二列
      val lineEndTimestamp = dateFormat.parse(parts(2)).getTime  // 假设结束时间在第三列
      lineStartTimestamp >= startTimestamp && lineEndTimestamp <= endTimestamp
    }
    writeToFile(updatedLines, filename)
  }


  def writeToFile(lines: List[String], filename: String): Unit = {
    val pw = new PrintWriter(new File(filename))
    lines.foreach(pw.println)
    pw.close()
  }
}
