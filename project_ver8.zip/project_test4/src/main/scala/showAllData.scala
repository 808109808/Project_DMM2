// ShowAllData.scala

import java.io.File
import scala.io.Source
import java.time.format.DateTimeFormatter

object showAllData {

  def showAllData(fileNames: List[String], globalStartDate: String, globalEndDate: String): Unit = {
    var totalEnergy = 0.0
    val energies = scala.collection.mutable.Map[String, Double]()

    fileNames.foreach { filename =>
      val src = Source.fromFile(filename)
      try {
        val lines = src.getLines()
        val header = lines.next()
        val startTimeIndex = header.split(",").indexWhere(_.trim == "startTime")
        val endTimeIndex = header.split(",").indexWhere(_.trim == "endTime")
        val valueIndex = header.split(",").indexWhere(_.trim == "value")
        val energyData = lines.map { line =>
          val parts = line.split(",")
          (parts(startTimeIndex), parts(endTimeIndex), parts(valueIndex).toDouble)
        }.toList

        val dates = energyData.map(_._1) ++ energyData.map(_._2)
        val minDate = dates.min
        val maxDate = dates.max
        val total = energyData.map(_._3).sum

        println(s"${filename.split("\\\\").last}:")
        println(s"Data range: $minDate to $maxDate")
        println(s"Total Energy: $total kWh")

        energies(filename.split("\\\\").last) = total
        totalEnergy += total
      } finally {
        src.close()
      }
    }

    println(s"\nTotal Energy from all sources: $totalEnergy kWh")
    energies.foreach { case (source, energy) =>
      val percentage = (energy / totalEnergy) * 100
      println(s"Percentage of $source: $percentage%")
    }
  }
}
