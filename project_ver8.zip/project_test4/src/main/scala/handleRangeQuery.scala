import java.util.Scanner
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class handleRangeQuery(dataManager: EnergyDataManager, scanner: Scanner, formatter: DateTimeFormatter) {
  val dateTimePattern = "\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z".r

  def handleRangeQuery(dataType: String, filename: String): Unit = {
    var start = false
    var end = false
    while (!start && !end) {
      println(s"\nEnter the start time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
      val startTimeString = scanner.nextLine()
      println("Enter the end time (yyyy-MM-dd'T'HH:mm:ss.SSS'Z'):(If you want to quit, press '0')")
      val endTimeString = scanner.nextLine()
      // Check if user wants to exit
      if (startTimeString == "0" || endTimeString == "0") {
        return // Exit the function
      }

      if (checkDate(startTimeString) && checkDate(endTimeString)) {
        start = true
        end = true
        val data = dataManager.fetchDataInRange(filename, startTimeString, endTimeString)
        println(s"\nDo you want to sort the data by the value. (Y/N)?")
        val shouldSort = scanner.nextLine().toUpperCase
        dataManager.printData(data, shouldSort == "Y")
      } else if(checkDate(startTimeString) && !checkDate(endTimeString)){
        println("There is a problem with your end time input.")
      } else if(!checkDate(startTimeString) && checkDate(endTimeString)){
        println("There is a problem with your start time input.")
      } else{
        val startDate = LocalDateTime.parse(startTimeString, formatter)
        val endDate = LocalDateTime.parse(endTimeString, formatter)
        if(endDate.isBefore(startDate)){
          println("Your end time is earlier than your start time.")
        }else{
          println("Something wrong.")
        }
      }
    }
  }

  private def checkDate(date: String): Boolean = {
    if (dateTimePattern.matches(date)) {
      true
    } else {
      println("Your input does not conform to the required format: yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
      false
    }
  }
}
